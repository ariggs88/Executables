﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Riggs_Masonry_Application
{
    public partial class Form1 : Form
    {
        double heightInFeet, lengthInFeet, standardBrick, oversizeBrick, cinderBlock;
        string dropDownDescrip = "Please select a brick\nor block to Calculate";
        

        public Form1()
        {
            InitializeComponent();
            selectionStatement.Text = dropDownDescrip;
        }

        private void close_Click(object sender, EventArgs e)
        {
            Close();
        }
        
        private void comboBox_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            lblError.Visible = false;
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            lblError.Visible = false;
        }

        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            lblError.Visible = false;
            textBox1.Clear();
        }

        private void textBox2_MouseDown(object sender, MouseEventArgs e)
        {
            lblError.Visible = false;
            textBox2.Clear();
        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            lblError.Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                lengthInFeet = double.Parse(textBox1.Text);
            }
            catch (FormatException)
            {
                textBox1.Clear();
                textBox2.Clear();
                lblError.Visible = true;
                lblError.Text = ("Please enter a numerical value\n\n");

            }
        }



private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                heightInFeet = double.Parse(textBox2.Text);
            }
            catch (FormatException)
            {
                textBox1.Clear();
                textBox2.Clear();
                lblError.Visible = true;
                lblError.Text = "Please enter a numerical value\n\n";
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                lblError.Visible = false;
                if (comboBox.SelectedItem.ToString() == "Standard Brick")
                {
                    standardBrick = lengthInFeet * heightInFeet * 9;
                    lblResult.Text = "Standard Brick = " + standardBrick;
                    lblResult.Visible = true;
                }

                else if (comboBox.SelectedItem.ToString() == "Oversize Brick")
                {
                    oversizeBrick = lengthInFeet * heightInFeet * 5;
                    lblResult.Text = "Oversize Brick = " + oversizeBrick;
                    lblResult.Visible = true;
                }

                else if (comboBox.SelectedItem.ToString() == "Cinder Block")
                {
                    cinderBlock = lengthInFeet * heightInFeet * .89;
                    lblResult.Text = "Cinder Block = " + cinderBlock;
                    lblResult.Visible = true;
                }
                else
                {
                    lblError.Visible = true;
                    lblError.Text = "Please Select a brick or block to calculate.";
                }
            }

            catch (NullReferenceException nre)
            {
                MessageBox.Show("Please Select a brick or block to calculate \n\n" + "Error: " + nre.Message);
            }
        }
    }
}
