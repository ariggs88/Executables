﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Riggs_Masonry_Application
{
    public partial class Form1 : Form
    {
        double heightInFeet;
        double lengthInFeet;
        double standardBrick;
        double oversizeBrick;
        double cinderBlock;

        public Form1()
        {
            InitializeComponent();
        }

        private void close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            lengthInFeet = double.Parse(textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {          
            heightInFeet = double.Parse(textBox2.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (comboBox.SelectedItem.ToString() == "Standard Brick")
            {
                standardBrick = lengthInFeet * heightInFeet * 9;
                MessageBox.Show("Standard Brick = " + standardBrick);                
            }

            if (comboBox.SelectedItem.ToString() == "Oversize Brick")
            {
                oversizeBrick = lengthInFeet * heightInFeet * 5;
                MessageBox.Show("Oversize Brick = " + oversizeBrick);
            }

            if (comboBox.SelectedItem.ToString() == "Cinder Block")
            {
                cinderBlock = lengthInFeet * heightInFeet * .89;
                MessageBox.Show("Cinder Block = " + cinderBlock);
            }
            

        }
    }
}
