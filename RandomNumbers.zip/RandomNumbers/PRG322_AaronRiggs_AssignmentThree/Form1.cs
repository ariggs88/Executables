﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace PRG322_AaronRiggs_AssignmentThree
{
    public partial class Form1 : Form
    {
        StreamReader inFile;
        StreamWriter outFile;
        string fileName = "randomNumbers.txt";

        public Form1()
        {
            InitializeComponent();
        }

//FORM LOAD!!!!!!!!
        // on form load create five columns and ten rows of random numbers using the Random() function. 
        // all of the numbers are seperated with a space (" ");
        private void Form1_Load(object sender, EventArgs e)
        {
            btnShowData.Visible = true;
            try
            {
                outFile = new StreamWriter(fileName);
            }
            catch (DirectoryNotFoundException exc)
            {
                lblMessage.Visible = true;
                lblMessage.Text = "Invalid Directory:\t" + exc.Message;
            }
            catch (System.IO.IOException exc)
            {
                lblMessage.Visible = true;
                lblMessage.Text = exc.Message;
            }
            /*
            Random rnd = new Random();
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "|");
            outFile.Write(rnd.Next(0, 1001) + "\n");
            */
            
                        Random rnd = new Random();
                        for (int j = 0; j < 10; ++j)
                        {
                            for (int i = 0; i < 5; ++i)
                            {
                                outFile.Write(rnd.Next(0, 1001));
                                outFile.Write('|');

                            }
                            outFile.Write("\\n");
                        }
                        
            outFile.Close();
        }



        //This button shows the data created at form load or with the generate random number button 
        // to a listbox... 

//BUTTON SHOW DATA
        private void btnShowData_Click(object sender, EventArgs e)
        {
            //seperate strings into an array of individual strings
            //loop through that array and take each element from it
            //parse it to an integer
            //add the integer to a List<int>
            //after loop completes use min and max methods to get the min and max.
            string inValue;
            string s;
            

            if (File.Exists(fileName))
            {
                btnShowMin.Visible = true;
                btnShowMax.Visible = true;
                inFile = new StreamReader(fileName);
                
                try
                {
                    // OKAY so now it works but it only takes the first 5 numbers and loops them
                    // how do I fix this? 
                   while ((inValue = inFile.ReadLine()) != null)
                    {
                        string[] individualValues = inValue.Split('|', '\n');
                        int l = individualValues.Length - 1;

                        for (int j = 0; j < 5; ++j)
                        {
                            s = individualValues[j];
                            lstBxRanNum.Items.Add(int.Parse(s));

                            for (int i = 0; i < 10; i++)
                            {
                                
                               
                            }

                        }
                        
                    }
                  

                }
                catch (FormatException fex)
                {
                    MessageBox.Show("Exception Thrown: " + fex.Message);
                }
            }
            else
            {
                MessageBox.Show("File Does Not Exist");

            }
            
        }
        
    

//BUTTON CLEAR DATA      GOT RID OF THIS       
        private void btnClearData_Click(object sender, EventArgs e)
        {
                 
        }

        //Since I changed the color of the button starting off with it was hard to tell if the button was
        //pressed down or not.  So I changed the color of each button when it is clicked, hovered over, 
        //and when the mouse leaves it goes back to the same color so you can tell it is a button. 

//BUTTON COLORS
        private void btnClearData_MouseHover(object sender, EventArgs e)
        {
           // btnClearData.BackColor = Color.DarkGray;
        }

        private void btnClearData_MouseLeave(object sender, EventArgs e)
        {
            // btnClearData.BackColor = Color.Black;
        }

        private void btnClearData_MouseClick(object sender, MouseEventArgs e)
        {
            // btnClearData.BackColor = Color.DarkBlue;
           // btnClearData.ForeColor = Color.White;
        }

        private void btnGRanNum_MouseHover(object sender, EventArgs e)
        {
            //btnGRanNum.BackColor = Color.DarkGray;
        }

        private void btnGRanNum_MouseLeave(object sender, EventArgs e)
        {
            //btnGRanNum.BackColor = Color.Black;
        }

        private void btnGRanNum_MouseClick(object sender, MouseEventArgs e)
        {
            //btnGRanNum.BackColor = Color.DarkBlue;
           // btnGRanNum.ForeColor = Color.White;
        }

        private void btnShowData_MouseHover(object sender, EventArgs e)
        {
            btnShowData.BackColor = Color.DarkGray;
        }

        private void btnShowData_MouseLeave(object sender, EventArgs e)
        {
            btnShowData.BackColor = Color.Black;
        }

        private void btnShowData_MouseClick(object sender, MouseEventArgs e)
        {
            btnShowData.BackColor = Color.DarkBlue;
            btnShowData.ForeColor = Color.White;
        }

        private void btnShowMin_MouseHover(object sender, EventArgs e)
        {
            btnShowMin.BackColor = Color.DarkGray;
        }

        private void btnShowMin_MouseLeave(object sender, EventArgs e)
        {
            btnShowMin.BackColor = Color.Black;
        }

        private void btnShowMin_MouseClick(object sender, MouseEventArgs e)
        {
            btnShowMin.BackColor = Color.DarkBlue;
            btnShowMin.ForeColor = Color.White;

        }

        private void btnShowMax_MouseHover(object sender, EventArgs e)
        {
            btnShowMax.BackColor = Color.DarkGray;
        }

        private void btnShowMax_MouseLeave(object sender, EventArgs e)
        {
            btnShowMax.BackColor = Color.Black;
        }

        private void btnShowMax_MouseClick(object sender, MouseEventArgs e)
        {
            btnShowMax.BackColor = Color.DarkBlue;
            btnShowMax.ForeColor = Color.White;
        }

        //If you wish to generate more random numbers after you click clear data this button becomes 
        //visible.  Then you can generate more random numbers using the same code.  probably could have
        //created a class and made this a function to shorten up but it isn't used that much so I feel
        //that is a little un called for. 

//BUTTON GENERATE RANDOM NUMBER got rid of this as well

        private void btnGRanNum_Click(object sender, EventArgs e)
        {
        }

//Show Minimum Number on button click
        private void btnShowMin_Click(object sender, EventArgs e)
        {
            var numbers = lstBxRanNum.Items.Cast<object>().Select(obj => Convert.ToInt32(obj));
            int min = numbers.Min();
            lblAnswerMin.Text = "Lowest #: " + min;
        }

        private void btnShowMax_Click(object sender, EventArgs e)
        {
            var numbers = lstBxRanNum.Items.Cast<object>().Select(obj => Convert.ToInt32(obj));
            int max = numbers.Max();
            lblAnswerMax.Text = "Highest #: " + max;
        }
    }
}

