﻿namespace PRG322_AaronRiggs_AssignmentThree
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblMessage = new System.Windows.Forms.Label();
            this.lstBxRanNum = new System.Windows.Forms.ListBox();
            this.btnShowData = new System.Windows.Forms.Button();
            this.lblAnswerMin = new System.Windows.Forms.Label();
            this.lblAnswerMax = new System.Windows.Forms.Label();
            this.btnShowMin = new System.Windows.Forms.Button();
            this.btnShowMax = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.Red;
            this.lblMessage.Location = new System.Drawing.Point(13, 479);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 23);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.Visible = false;
            // 
            // lstBxRanNum
            // 
            this.lstBxRanNum.BackColor = System.Drawing.Color.Black;
            this.lstBxRanNum.Font = new System.Drawing.Font("Baskerville Old Face", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstBxRanNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lstBxRanNum.FormattingEnabled = true;
            this.lstBxRanNum.ItemHeight = 23;
            this.lstBxRanNum.Location = new System.Drawing.Point(127, 117);
            this.lstBxRanNum.Name = "lstBxRanNum";
            this.lstBxRanNum.Size = new System.Drawing.Size(452, 211);
            this.lstBxRanNum.TabIndex = 1;
            // 
            // btnShowData
            // 
            this.btnShowData.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnShowData.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowData.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnShowData.Location = new System.Drawing.Point(127, 334);
            this.btnShowData.Name = "btnShowData";
            this.btnShowData.Size = new System.Drawing.Size(104, 36);
            this.btnShowData.TabIndex = 2;
            this.btnShowData.Text = "Show Data";
            this.btnShowData.UseVisualStyleBackColor = false;
            this.btnShowData.Visible = false;
            this.btnShowData.Click += new System.EventHandler(this.btnShowData_Click);
            this.btnShowData.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnShowData_MouseClick);
            this.btnShowData.MouseLeave += new System.EventHandler(this.btnShowData_MouseLeave);
            this.btnShowData.MouseHover += new System.EventHandler(this.btnShowData_MouseHover);
            // 
            // lblAnswerMin
            // 
            this.lblAnswerMin.AutoSize = true;
            this.lblAnswerMin.BackColor = System.Drawing.Color.Black;
            this.lblAnswerMin.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswerMin.ForeColor = System.Drawing.Color.Teal;
            this.lblAnswerMin.Location = new System.Drawing.Point(453, 396);
            this.lblAnswerMin.Name = "lblAnswerMin";
            this.lblAnswerMin.Size = new System.Drawing.Size(119, 27);
            this.lblAnswerMin.TabIndex = 5;
            this.lblAnswerMin.Text = "Lowest #: ";
            // 
            // lblAnswerMax
            // 
            this.lblAnswerMax.AutoSize = true;
            this.lblAnswerMax.BackColor = System.Drawing.Color.Black;
            this.lblAnswerMax.Font = new System.Drawing.Font("Baskerville Old Face", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswerMax.ForeColor = System.Drawing.Color.Teal;
            this.lblAnswerMax.Location = new System.Drawing.Point(445, 423);
            this.lblAnswerMax.Name = "lblAnswerMax";
            this.lblAnswerMax.Size = new System.Drawing.Size(134, 27);
            this.lblAnswerMax.TabIndex = 6;
            this.lblAnswerMax.Text = "Highest #:  ";
            // 
            // btnShowMin
            // 
            this.btnShowMin.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnShowMin.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowMin.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnShowMin.Location = new System.Drawing.Point(475, 334);
            this.btnShowMin.Name = "btnShowMin";
            this.btnShowMin.Size = new System.Drawing.Size(104, 36);
            this.btnShowMin.TabIndex = 7;
            this.btnShowMin.Text = "Show Min #";
            this.btnShowMin.UseVisualStyleBackColor = false;
            this.btnShowMin.Visible = false;
            this.btnShowMin.Click += new System.EventHandler(this.btnShowMin_Click);
            this.btnShowMin.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnShowMin_MouseClick);
            this.btnShowMin.MouseLeave += new System.EventHandler(this.btnShowMin_MouseLeave);
            this.btnShowMin.MouseHover += new System.EventHandler(this.btnShowMin_MouseHover);
            // 
            // btnShowMax
            // 
            this.btnShowMax.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnShowMax.Font = new System.Drawing.Font("Baskerville Old Face", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowMax.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnShowMax.Location = new System.Drawing.Point(297, 334);
            this.btnShowMax.Name = "btnShowMax";
            this.btnShowMax.Size = new System.Drawing.Size(104, 36);
            this.btnShowMax.TabIndex = 8;
            this.btnShowMax.Text = "Show Max #";
            this.btnShowMax.UseVisualStyleBackColor = false;
            this.btnShowMax.Visible = false;
            this.btnShowMax.Click += new System.EventHandler(this.btnShowMax_Click);
            this.btnShowMax.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnShowMax_MouseClick);
            this.btnShowMax.MouseLeave += new System.EventHandler(this.btnShowMax_MouseLeave);
            this.btnShowMax.MouseHover += new System.EventHandler(this.btnShowMax_MouseHover);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.Color.Transparent;
            this.lblHeader.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblHeader.Font = new System.Drawing.Font("Baskerville Old Face", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.ForeColor = System.Drawing.Color.Navy;
            this.lblHeader.Location = new System.Drawing.Point(109, 24);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(489, 69);
            this.lblHeader.TabIndex = 9;
            this.lblHeader.Text = "Random Numbers";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(707, 508);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.btnShowMax);
            this.Controls.Add(this.btnShowMin);
            this.Controls.Add(this.lblAnswerMax);
            this.Controls.Add(this.lblAnswerMin);
            this.Controls.Add(this.btnShowData);
            this.Controls.Add(this.lstBxRanNum);
            this.Controls.Add(this.lblMessage);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Random Numbers";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ListBox lstBxRanNum;
        private System.Windows.Forms.Button btnShowData;
        private System.Windows.Forms.Label lblAnswerMin;
        private System.Windows.Forms.Label lblAnswerMax;
        private System.Windows.Forms.Button btnShowMin;
        private System.Windows.Forms.Button btnShowMax;
        private System.Windows.Forms.Label lblHeader;
    }
}

